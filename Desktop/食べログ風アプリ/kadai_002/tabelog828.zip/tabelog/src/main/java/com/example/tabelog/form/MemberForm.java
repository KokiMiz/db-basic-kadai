package com.example.tabelog.form;

public class MemberForm {

}
