package com.example.tabelog.form;

public class ReservationForm {

}
