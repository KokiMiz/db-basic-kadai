package com.example.tabelog.form;

public class UserForm {

}
