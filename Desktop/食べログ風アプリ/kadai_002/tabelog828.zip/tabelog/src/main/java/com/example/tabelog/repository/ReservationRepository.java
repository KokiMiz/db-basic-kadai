package com.example.tabelog.repository;

public interface ReservationRepository {

}
