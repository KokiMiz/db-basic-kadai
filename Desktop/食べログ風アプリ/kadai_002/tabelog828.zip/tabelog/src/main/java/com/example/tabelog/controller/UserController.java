package com.example.tabelog.controller;

public class UserController {

}
