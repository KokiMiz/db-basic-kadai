package com.example.tabelog.service;

public class ReviewService {

}
